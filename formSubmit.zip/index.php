<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FormSubmission</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
</head>
<body>

        <div class="container mt-5">
            Name:<div class="form-group">
                <input type="text" class="form-control name" id="name" autocomplete="off">
            </div>
    Email<div class="form-group">
                <input type="email" class="form-control email" id="email"  autocomplete="off">
            </div>
        Number:<div class="form-group">
                <input type="number" class="form-control number"id="number"  autocomplete="off">
            </div>  
            <br>
            <div class="form-group">
                <input type="submit" class="btn btn-success btn-block submit" value="SUBMIT">
            </div>




        </div>
        <div class="alert-b">

        </div>
        <div class="a"></div>


    
</body>
<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<script src="main.js"></script>

</html>