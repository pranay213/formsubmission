$(document).ready(function()
{
$('.submit').on('click',function(e)

{   e.preventDefault()  
      var name=$('#name').val();
        var email=$('#email').val();
        var number=$('#number').val();
        if(name!="" && email!="" &&number!="")
        {
        $.ajax(
            {
                url:'send.php',
                type:'POST',
                data:{name:name,email:email,number:number},
                success:function(data)
                {       $('#name').val("");
                        $('#email').val('');  
                        $('#number').val('');
                       data=`<div class="alert alert-success" role="alert">
                                 ${name} inserted successfully
                       </div>;
                                `
                        setTimeout(function() {
                            $('.alert-b').html(data).show('slow');
                        }, 1000);
                        setTimeout(function() {
                            $('.alert-b').html(data).hide('slow');
                        }, 3000);
                   
                    
                }
                
            }
        )
        }
        else{
            data=`<div class="alert alert-danger" role="alert">
            Please fill all details
        </div>`;
        setTimeout(function() {
            $('.alert-b').html(data).show('slow');
        }, 1000);
        setTimeout(function() {
            $('.alert-b').html(data).hide('slow');
        }, 3000);

        }
        
   

        
    
   
})

})