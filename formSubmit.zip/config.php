<?php 

 $host="localhost";
 $username="root";
 $password="";
 $dbname="form";
 $conn=mysqli_connect($host,$username,$password,$dbname) or die('error in connection');

?>