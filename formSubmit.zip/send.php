<?php
include "config.php";
$name=$_POST['name'];
$email=$_POST['email'];
$number=$_POST['number'];




echo $insert="INSERT INTO users(name,email,number) VALUES('{$name}','{$email}','{$number}')";
$res=mysqli_query($conn,$insert) or ("query error ");

?>